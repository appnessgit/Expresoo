This module adds Helpdesk functionality in Odoo.
